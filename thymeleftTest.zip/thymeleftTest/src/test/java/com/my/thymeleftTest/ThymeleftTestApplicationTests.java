package com.my.thymeleftTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleftTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
